<?php
if(isset($_REQUEST['id'])){
 $connect = mysqli_connect("localhost", "root", "", "sqli");
  $sql = "SELECT * FROM infos_eve WHERE id_eve=".$_REQUEST['id'];
 $result = mysqli_query($connect, $sql);  
 $row = mysqli_fetch_array($result);

	$output = " <table border='1' class='details'>
		<tr>
		<td class='titl'><b>Tracnhe d'âge</b></td>
		<td class='tage' data-id=".$_REQUEST['id']." contenteditable>".$row['tage']."</td>
		</tr>

		<tr>
		<td class='titl'><b>Objectifs</b></td>
		<td class='objectifs' data-id=".$_REQUEST['id']." contenteditable>".$row['objectifs']."</td>
		</tr>

		";
		echo $output;
}

?>