<?php  
 $connect = mysqli_connect("localhost", "root", "", "sqli");
    if (!$connect) {
        echo "Error: Unable to connect to MySQL." . PHP_EOL;
        echo "Debugging errno: " . mysqli_connect_errno() . PHP_EOL;
        echo "Debugging error: " . mysqli_connect_error() . PHP_EOL;
        exit;
    }
 $output = '';  
 $sql = "SELECT * FROM infos_eve";

 if(isset($_REQUEST['search'])){
  $crit = $_REQUEST['search']; 
  $sql .= " WHERE titre LIKE '%$crit%' ";
 }
 $result = mysqli_query($connect, $sql);  
 $output .= '  
      <div class="table-responsive">  
           <table class="table table-bordered">  
                <tr>  
                     <th width="10%">Titre</th>
                     <th width="10%">Date</th>
                     <th width="10%">Prix</th>
                     <th width="10%">Type</th>
                     <th width="10%">Operation</th>
                </tr>';  
 $rows = mysqli_num_rows($result);
 if($rows > 0)  
 {  
	  if($rows > 10)
	  {
		  $delete_records = $rows - 10;
		  $delete_sql = "DELETE FROM infos_eve LIMIT $delete_records";
		  mysqli_query($connect, $delete_sql);
	  }
      while($row = mysqli_fetch_array($result))  
      {  
           $output .= '  
                <tr>  
                     <td class="titre" data-id="'.$row["id_eve"].'" contenteditable>'.$row["titre"].'</td>
                     <td class="date" data-id="'.$row["id_eve"].'" contenteditable>'.$row["date"].'</td>
                     <td class="prix" data-id="'.$row["id_eve"].'" contenteditable>'.$row["prix"].'</td>
                     <td class="type" data-id="'.$row["id_eve"].'" contenteditable>'.$row["type"].'</td>
                     <td><button type="button" name="delete_btn" data-id="'.$row["id_eve"].'" class="btn btn-xs btn-danger btn_delete">Supprimer<span class="tooltiptext">Supprimer</span></button>
                  <button type="button" name="view_btn" data-id="'.$row["id_eve"].'" class="btn btn-xs btn-success view_btn">Afficher détails<span class="tooltiptext">Afficher</span></button></td>
                </tr>  
           ';  
      }  
      $output .= '  
           <tr>  
              
           </tr>  
      ';  
 }  
 else  
 {  
      $output .= '
				<tr>  
					<td colspan=5> RIEN</td> 
			   </tr>';  
 }  

 $output .= '</table>  
      </div>';  


 echo $output;  
 ?>
