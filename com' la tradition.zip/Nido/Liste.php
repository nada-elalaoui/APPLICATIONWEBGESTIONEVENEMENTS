<html>  
    <head>  
        <title>Gestionnaire de PC</title>  
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />  
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>  
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>  
        <style type="text/css">
            button:focus {
                outline: 0;
                box-shadow: none!important;
            }
                        tr:hover{
                            background-color: yellow;
                        }

                        .details td {
                            width: 15%;
                            height:20px;
                            padding: 10px;
                        }
                        .titl {
                            background-color: #aa9a9a;
                        }

                        .view_btn {
            position: relative;
            display: inline-block;
            border-bottom: 1px dotted black;
            }

            .btn_delete {
            position: relative;
            display: inline-block;
            border-bottom: 1px dotted black;
            }

            .view_btn .tooltiptext {
            visibility: hidden;
            width: 120px;
            background-color: black;
            color: #fff;
            text-align: center;
            border-radius: 6px;
            padding: 5px 0;

            /* Position the tooltip */
            position: absolute;
            z-index: 1;
            }

            .btn_delete .tooltiptext {
            visibility: hidden;
            width: 120px;
            background-color: black;
            color: #fff;
            text-align: center;
            border-radius: 6px;
            padding: 5px 0;

            /* Position the tooltip */
            position: absolute;
            z-index: 1;
            }

            .view_btn:hover .tooltiptext {
            visibility: visible;
            }

            .btn_delete:hover .tooltiptext {
            visibility: visible;
            }
        </style>
    </head>  
    <body>  
        <div class="container">  
            <br />  
            <br />
			<br />
			<div class="table-responsive">  
            <span style="color:#8e224d; text-align:center"><h3> Gestionnaire des évènements</h3></span><br />
                <input type="text" class="form-control search" id="search" placeholder="Checher ici par: titre" name="search" autocomplete="off" required> <br>
				<span id="result"></span>
				<div id="live_data"></div>                 
			</div>  
            <div id="details"></div>
		</div>
    </body>  
</html>  
<script>  
$(document).ready(function(){  
    function fetch_data()  
    {  
        $.ajax({  
            url:"select.php",  
            method:"POST",  
            success:function(data){  
				$('#live_data').html(data);  
            }  
        });  
    }  
    fetch_data();  
    $(document).on('click', '#btn_add', function(){  
        var first_name = $('#first_name').text();  
        var last_name = $('#last_name').text();  
        if(first_name == '')  
        {  
            alert("Enter First Name");  
            return false;  
        }  
        if(last_name == '')  
        {  
            alert("Enter Last Name");  
            return false;  
        }  
        $.ajax({  
            url:"insert.php",  
            method:"POST",  
            data:{first_name:first_name, last_name:last_name},  
            dataType:"text",  
            success:function(data)  
            {  
                alert(data);  
                fetch_data();  
            }  
        })  
    });  
    
	function edit_data(id, text, column_name)  
    {  
        $.ajax({  
            url:"edit.php",  
            method:"POST",  
            data:{id:id, text:text, column_name:column_name},  
            dataType:"text",  
            success:function(data){  
                //alert(data);
				$('#result').html("<div class='alert alert-success'>Modification effectuée!</div>");
            }  
        });  
    }  
    $(document).on('blur', '.titre', function(){  
        var id = $(this).data("id");  
        var new_titre = $(this).text();  
        edit_data(id, new_titre, "titre");  
    });  
        $(document).on('blur', '.date', function(){  
        var id = $(this).data("id");  
        var new_date = $(this).text();  
        edit_data(id, new_date, "date");  
    }); 
    $(document).on('blur', '.prix', function(){  
        var id = $(this).data("id");  
        var new_prix = $(this).text();  
        edit_data(id,new_prix, "prix");  
    }); 

       $(document).on('input', '.search', function(){  
        var id = $(this).value;  
        var last_name = $(this).text();
        $.ajax({  
            url:"select.php?search="+document.getElementById('search').value,  
            method:"POST",
            success:function(data){  
                $('#live_data').html(data);  
            }  
        });  
        console.log("HELLO");
    }); 
        $(document).on('blur', '.type', function(){  
        var id = $(this).data("id");  
        var new_type = $(this).text();  
        edit_data(id, new_type, "type");  
    }); 
         $(document).on('blur', '.tage', function(){  
        var id = $(this).data("id");  
        var new_tage = $(this).text();  
        edit_data(id, new_tage, "tage");  
  }); 
         $(document).on('blur', '.objectifs', function(){  
        var id = $(this).data("id");  
        var new_objectifs = $(this).text();  
        edit_data(id, new_objectifs, "objectifs");  
  }); 
         
    $(document).on('click', '.btn_delete', function(){  
        var id=$(this).data("id");  
        if(confirm("Vous êtes sûr au supression?"))  
        {  
            $.ajax({  
                url:"delete.php",  
                method:"POST",  
                data:{id:id},  
                dataType:"text",  
                success:function(data){  
                    alert(data);  
                    fetch_data();  
                }  
            });  
        }  
    });  
    $(document).on('click', '.view_btn', function(){  
        var id=$(this).data("id");  
        if(1)  
        {  
            $.ajax({  
                url:"details.php",  
                method:"POST",  
                data:{id:id},  
                dataType:"text",  
                success:function(data){  
                    $('#details').html(data);  
                }  
            });  
        }  
    }); 
});  
</script>