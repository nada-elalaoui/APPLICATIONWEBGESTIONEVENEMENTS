<?php  
	$connect = mysqli_connect("localhost", "root", "", "sqli");
	$sql = "DELETE FROM infos_eve WHERE id_eve = '".$_POST["id"]."'";  
	if(mysqli_query($connect, $sql))  
	{  
		echo 'Modification effectuée!';  
	}  
 ?>