<?php
require_once 'db.php';
if (isset($_POST["add"])) {
$titre = $_POST["titre"];
$date = $_POST["date"];
$type = $_POST["type"];
$tage  = $_POST["tage"];
$prix  = $_POST["prix"];
$obj = $_POST["obj"];

$query = "INSERT INTO `infos_eve`(`titre`, `date`, `prix`, `type`, `tage`, `objectifs`) 
VALUES('".$titre."','" .$date ."','" .$prix ."','".$type."','" .$tage."','" .$obj."')" ;
$statement = $conn->prepare($query);
$statement->execute();
header('location:../Liste.php');
echo $query;
}
else {echo "bla";}

 ?>
