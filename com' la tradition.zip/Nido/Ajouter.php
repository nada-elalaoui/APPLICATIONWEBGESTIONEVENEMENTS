<!DOCTYPE html>
<html lang="en">
<head>
  <link rel="icon" href="images/logo.png"/>
  <title>Gestion stock</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">
  <span style="color:#8e224d; text-align:center"><h2>Ajouter un nouvel évènement</h2></span>
  <form method="POST" action="php/AjouterEve.php" class="was-validated">
    <div class="form-group">
      <div class='row'>
        <div class='col-lg-12'>
          <label>Titre d'évènement:</label>
          <input type="text" class="form-control" id="titre" placeholder="Enter le titre" name="titre" required>
          <div class="valid-feedback">Valid.</div>
          <div class="invalid-feedback">Please fill out this field.</div>
       </div>
     </div>
    </div>
    <div class="form-group">
      <div class='row'>
        <div class="col-lg-6">
          <div class="form-group">
            <label>Date:</label>
            <input type="date" class="form-control" id="date" placeholder="Enter la date de l'évènement" name="date" required>
            <div class="valid-feedback">Valid.</div>
            <div class="invalid-feedback">Please fill out this field.</div>
          </div>
        </div>
        <div class="col-lg-6">
          <div class="form-group">
            <label>Prix:</label>
            <input type="text" class="form-control" id="prix" placeholder="Enter le prix" name="prix" required>
            <div class="valid-feedback">Valid.</div>
            <div class="invalid-feedback">Please fill out this field.</div>
          </div>
        </div>
     </div>
    </div>
    <div class="form-group">
      <div class='row'>
        <div class="col-lg-6">
          <div class="form-group">
            <label>Type:</label>
            <select  class="form-control" name="type" id="type" required> 
              <option value="" selected>choisir un type</option>
              <option value="Broderie">Broderie</option>
              <option value="Cuisine">Cuisine</option>
            </select>
            <div class="valid-feedback">Valid.</div>
            <div class="invalid-feedback">Please fill out this field.</div>
          </div>
        </div>
    <div class="col-lg-6">
      <div class="form-group">
        <label>Tranche d'âge:</label>
        <select  class="form-control" name="tage" id="tage" required> 
          <option value="" selected>choisir une tranche d'âge</option>
          <option value="8-12">8-10</option>
          <option value="12-16">12-16</option>
          <option value="16-18">16-18</option>
          <option value="+18">+18</option>
        </select>
        <div class="valid-feedback">Valid.</div>
        <div class="invalid-feedback">Please fill out this field.</div>
      </div>
    </div>
    </div>
    </div>
    <div class="form-group">
      <div class='row'>
      <div class='col-lg-12'>
      <label>Objectifs d'évènement:</label>
      <input type="text-area" class="form-control" id="obj" placeholder="Enter les objectifs de l'évènement" name="obj" required>
      <div class="valid-feedback">Valid.</div>
      <div class="invalid-feedback">Please fill out this field.</div>
    </div>
    </div>
    </div>
    <button type="submit" class="btn btn-primary" name="add" style="background-color:#8e224d;margin-bottom:20px;margin-left:500px;size:40px;">Ajouter</button>
  </form>
</div>

</body>
</html>
