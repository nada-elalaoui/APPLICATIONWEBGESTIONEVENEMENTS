<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>
  <meta charset="utf-8">
  <link rel="icon" href="images/logo.png" />
  <title>Gestion des évènements</title>
  <link rel="icon" href="favicon.ico" />
  <link rel="stylesheet" href="css/style.css">
</head>

<body>
  <header>
    <nav>
      <div class="logo">
        <img src="images/logo.png" alt="image" height="80px" width="100px" style="margin-left:30px;">
      </div>
    </nav>
    <section>
      <div class="leftside">
        <img src="images/img1.png" alt="image">
      </div>
      <div class="rightside">
          <h2>Bienvenue à gestion des évènements de </h2>
          <h1>Com' La Tradition</h1>
          <br><br>
          <button type="button" name="button" style="margin-right:10px"><a href="Ajouter.php" style="text-decoration:none;">Ajouter</a></button>
          <button type="button" name="button" style="margin-right:10px"><a href="Liste.php" style="text-decoration:none;">Consulter</a></button>
      </div>
    </section>
  </header>
  </div>
</body>

</html>